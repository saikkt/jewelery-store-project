package com.eCommerce.jewelrystore.order.domain;

public enum OrderStatus {
    PLACED,
    ACCEPTED,
    SHIPPED,
    CANCELLED,
    CART
}
