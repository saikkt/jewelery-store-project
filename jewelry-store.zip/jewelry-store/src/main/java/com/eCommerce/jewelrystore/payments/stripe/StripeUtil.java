package com.eCommerce.jewelrystore.payments.stripe;

import com.eCommerce.jewelrystore.payments.util.PaymentUtil;

public interface StripeUtil extends PaymentUtil {


}
