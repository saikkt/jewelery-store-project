package com.eCommerce.jewelrystore.images.homepageslidingimages.utility;

public enum ImageOrientation {

    LEFT,
    RIGHT,
    UP,
    DOWN
}
